// Dashboard Module - Only loaded on dashboard pages


// Dashboard-specific widgets

// Map functionality for dashboard
// import 'jqvmap';
// import 'jqvmap/dist/maps/jquery.vmap.world.js';

// Dashboard notifications and widgets
// Note: Additional dashboard-specific libraries can be added here

// Dashboard-specific JavaScript
import $ from 'jquery';

// Flot charts
import 'flot/dist/es5/jquery.flot.js';

export default {
  initialized: true
}; 